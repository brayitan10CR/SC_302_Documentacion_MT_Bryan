Calendario
=========

A jQuery calendar plugin for creating flexible calendars.

[article on Codrops](http://tympanus.net/codrops/?p=12416)

[demo](http://tympanus.net/Development/Calendario)

[github demo](http://deviprsd21.github.io/Calendario/)

Licensed under the MIT License
